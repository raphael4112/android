package com.thecus.www.thecusconnect;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Roy Lu on 5/20/16.
 */
public class ClassSharedPrefMngr {

    private static ClassSharedPrefMngr instance =null;
    private static SharedPreferences mSharedPrefs;

    //Empty constructor
    private ClassSharedPrefMngr () {}

    public static ClassSharedPrefMngr getInstance() {
        if(instance == null)
            instance = new ClassSharedPrefMngr();
        return instance;
    }

    public void setmSharedPrefs(Context context) {
        mSharedPrefs = context.getSharedPreferences("ThecusConnect", Context.MODE_PRIVATE);
    }

    public void setUsername(String username) {
        mSharedPrefs.edit().putString("Username", username).apply();
    }

    public void setPassword(String password) {
        mSharedPrefs.edit().putString("Password", password).apply();
    }

    public void setNasIp(String nasIp) {
        mSharedPrefs.edit().putString("NAS IP", nasIp).apply();
    }

    public void setNasName(String nasName) {
        mSharedPrefs.edit().putString("NAS Name", nasName).apply();
    }

    public String getNasName() {
        String nasName = mSharedPrefs.getString("NAS Name", "");
        return nasName;
    }

    public void setAuthId(String authId) {
        mSharedPrefs.edit().putString("Auth ID", authId).apply();
    }


}
