package com.thecus.www.thecusconnect;

/**
 * Created by rlu on 5/23/16.
 */
public class ClassUri {
    public static final String TAG = ClassUri.class.getSimpleName();

    //public String getUri(String function) {



    //    return;
    //}


}
