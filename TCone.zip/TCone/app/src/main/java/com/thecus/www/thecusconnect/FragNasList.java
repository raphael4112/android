package com.thecus.www.thecusconnect;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FragNasList extends Fragment {

    public static final String TAG = FragNasList.class.getSimpleName();
    private static Context mContext;
    public static List<ClassNasDiscovered> mNasList;
    private ProgressDialog mProgressDialog;
    private AdapterNasList mCustomAdapter;

    public FragNasList() {
        // Empty constructor required for fragment subclasses
    }

    public static Fragment newInstance() {
        Fragment mFragNasList = new FragNasList();
        return mFragNasList;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "Creating view");
        mContext = getActivity().getApplicationContext();
        View fragView = inflater.inflate(R.layout.frag_nas_list, null);
        mNasList = new ArrayList<ClassNasDiscovered>();

        //Calling AsyncTask to scan for NAS in the network
        ScanTask mScanTask = new ScanTask(new OnScanListener() { //Initialize AsyncTask to scan network for NAS
            @Override
            public void onScanCompleted(List<ClassNasDiscovered> newNasList) {
                Log.d(TAG, "Network scanning completed");
                mNasList.clear();
                if (newNasList != null) {
                    for (int i = 0; i < newNasList.size(); i++) {
                        mNasList.add(newNasList.get(i)); // Add found NAS machines to NasList
                    }
                }
                //Cleans duplicates
                Log.v(TAG, "List length before sort: " + mNasList.size());
                Map<String, ClassNasDiscovered> map = new LinkedHashMap<>();
                for (ClassNasDiscovered nas : mNasList) {
                    map.put(nas.getName(), nas);
                }
                mNasList.clear();
                mNasList.addAll(map.values());
                Log.v(TAG, "List length after sort: " + mNasList.size());
                //Sorts NAS List alphabetically by name
                Collections.sort(mNasList, new Comparator<ClassNasDiscovered>() {
                    @Override
                    public int compare(ClassNasDiscovered nas1, ClassNasDiscovered nas2) {
                        return nas1.getName().compareTo(nas2.getName());
                    }
                });
                mCustomAdapter.notifyDataSetChanged(); //Update the data-link to adapter.
            }
        });

        //Check if
        WifiManager wifiManager = (WifiManager) getActivity().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager.isWifiEnabled()) {
            mScanTask.execute();
        } else {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
            alertDialog.setTitle("Connection Error")
                    .setMessage("Please turn on your Wifi! Thanks! \n \nThecusConnect needs to scan your network to find your network storage unit. ")
                    .show();
        }

        if (mNasList.size() == 0) {
            Log.e(TAG, "NasList is empty");
        } else {
            Log.d(TAG, "NasList includes " + mNasList);
        }
        //Set up list view for NasList
        ListView listView = (ListView) fragView.findViewById(R.id.listview_frag_nas_list);  //Reference ListView; then propagate through rootView to find ListView.
        mCustomAdapter = new AdapterNasList(
                mContext, //The current context (this activity)
                R.layout.item_nas,  //The name of the layout ID
                mNasList //Array list
        );
        listView.setAdapter(mCustomAdapter); //Attach an adapter to the listView.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long rowId){
                //Take the user to ActivityLogin
                Intent intentLogin = new Intent(getActivity(), ActivityLogin.class);
                intentLogin.putExtra("nasIp", mNasList.get(position).getIpInet());
                intentLogin.putExtra("nasName", mNasList.get(position).getName());
                Log.d(TAG, "Chosen NAS Name: " + mNasList.get(position).getName() + " IP address: "
                        + mNasList.get(position).getIpInet().getHostAddress());
                startActivity(intentLogin);
            }
        });
        //Set up image view for AddNas
        int imageId = getResources().getIdentifier("icon_plus",
                "drawable", getActivity().getPackageName());
        ImageView imageView = ((ImageView) fragView.findViewById(R.id.imageview_add_nas));
        imageView.setImageResource(imageId);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "AddNas clicked");
                FragNasList.this.addNas();
            }
        });
        Log.d(TAG, "Generate fragment view");
        return fragView;
    }

    public void addNas() {
        LayoutInflater dialogInflater = LayoutInflater.from(getActivity());
        View view = dialogInflater.inflate(R.layout.dialog_add_nas, null);
        //Set up the dialog overlay
        Log.d(TAG, "Generating Add NAS Dialog");
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        TextView tvDialogTitle = (TextView) getActivity().findViewById(R.id.tv_dialog_title);
        final EditText etNasIp = (EditText) getActivity().findViewById(R.id.et_nas_ip);
        builder.setTitle("Please enter NAS IP")
                .setView(view)
                .setPositiveButton("Find NAS", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int whichButton) {
                        String nasIP = etNasIp.getText().toString();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int whichButton) {
                        dialogInterface.cancel();
                    }
                })
                .show();
    }

    public interface OnScanListener {
        void onScanCompleted(List<ClassNasDiscovered> nasList);
    }

    public class ScanTask extends AsyncTask<Void, Void, List<ClassNasDiscovered>> { //AsyncTask to specify <Params, Progress, Results>

        private final String TAG =  ScanTask.class.getSimpleName();
        private OnScanListener mScanListener;

        public ScanTask (OnScanListener mScanListener) {
            this.mScanListener = mScanListener;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Show progress
            mProgressDialog = new ProgressDialog(getActivity());
            mProgressDialog.setMessage("Scanning network");
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        }
        @Override
        protected List<ClassNasDiscovered> doInBackground(Void... params) { //Returned value goes to onPostExecute
            List<ClassNasDiscovered> newNasList = new ArrayList<ClassNasDiscovered>();
            try {
                Log.i(TAG, "Background network scanning initiating");
                ClassUdpTools classUdpTools = new ClassUdpTools(mContext); //Initiate background process to scan network.
                classUdpTools.run(); //Run background process to scan network and add NAS to list.
                newNasList = classUdpTools.returnNasList(); //Call and fetch list
            } catch (Exception e) {
                Log.e(TAG, "Background network scanning error");
            }
            return newNasList;
        }
        @Override
        protected void onPostExecute(List<ClassNasDiscovered> newNasList) { //onPostExecute is executed on UI thread.
            super.onPostExecute(newNasList);
            //Dismiss
            if (mProgressDialog.isShowing())
                mProgressDialog.dismiss();
            mScanListener.onScanCompleted(newNasList); //Call back through AsyncTask listener
        }
    }

}

