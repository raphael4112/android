package com.thecus.www.thecusconnect;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * Created by Roy Lu on 5/17/16.
 */
public class FragSystemHealth extends Fragment{
    public static final String TAG = FragSystemHealth.class.getSimpleName();

    public FragSystemHealth() {
        // Empty constructor required for fragment subclasses
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /*
    public static Fragment newInstance() {
        Fragment fragSystemHealth = new FragSystemHealth();
        return fragSystemHealth;
    }
    */

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "Creating view");
        View fragView = inflater.inflate(R.layout.frag_system_health, container, false); //Instantiate view.
        ImageView ivBg = (ImageView) fragView.findViewById(R.id.iv_bg_frag_system_health);

        return fragView;
    }
}