package com.thecus.www.thecusconnect;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by Roy Lu on 5/16/16.
 */
public class ActivitySystem extends AppCompatActivity {
    public static final String TAG = ActivitySystem.class.getSimpleName();
    private FragmentTabHost mFragTabHost;
    private FragmentManager mFragMngr;
    private FragmentTransaction mFragTrans;
    private String mNasName;

    @Override
    protected void onCreate(Bundle savedInstanceState) { //Method run when the activity is created
        Log.d(TAG, "Creating ActivitySystem");
        super.onCreate(savedInstanceState); //Background code in Android Activity is run here
        setContentView(R.layout.activity_system);  //Set the layout

        getSharedPrefs(); //Call and retrieve user info for this activity

        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layout_system);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        TextView tvToolbarTitle = (TextView) findViewById(R.id.tv_toolbar_title);
        tvToolbarTitle.setText(getText(R.string.app_name));
        TextView textView = (TextView) findViewById(R.id.textview_nas_name);
        textView.setText(mNasName);

        /*
        Fragment fragSystemGeneral = FragSystemGeneral.newInstance();
        Fragment fragSystemHealth = FragNasList.newInstance();
        mFragMngr= getFragmentManager();
        mFragTrans = mFragMngr.beginTransaction();
        mFragTrans.add(R.id.framelayout_frag_system_general, fragSystemGeneral);
        mFragTrans.add(R.id.framelayout_add_nas, fragSystemHealth);
        mFragTrans.commit();
        */

        mFragTabHost = (FragmentTabHost) findViewById(R.id.frag_tab_host);
        mFragTabHost.setup(this, getSupportFragmentManager(), R.id.framelayout_tab_content);

        mFragTabHost.addTab(mFragTabHost.newTabSpec("general").setIndicator("General", null),
                FragSystemGeneral.class, null);
        mFragTabHost.addTab(mFragTabHost.newTabSpec("health").setIndicator("Health", null),
                FragSystemHealth.class, null);
        mFragTabHost.addTab(mFragTabHost.newTabSpec("network").setIndicator("Network", null),
                FragSystemNetwork.class, null);
    }

    public void getSharedPrefs() {
        ClassSharedPrefMngr mSharedPrefsMngr = ClassSharedPrefMngr.getInstance();
        mSharedPrefsMngr.setmSharedPrefs(getApplicationContext());
        mNasName = mSharedPrefsMngr.getNasName();
        /*
        mSharedPrefsMngr.setNasIp(mNasIp.getHostAddress());
        mSharedPrefsMngr.setUsername(mUsername);
        mSharedPrefsMngr.setPassword(mPassword);
        mSharedPrefsMngr.setAuthId(mAuthId);
        */
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tool_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle tool bar item clicks here. The action bar will automatically handle clicks
        // on the Home/Up button, so long as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_nav_drawer) {
            Intent navDrawer = new Intent(this, ActivityPlanets.class);
            startActivity(navDrawer);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}