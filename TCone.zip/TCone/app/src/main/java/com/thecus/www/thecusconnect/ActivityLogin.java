package com.thecus.www.thecusconnect;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.InetAddress;

/**
 * Created by Roy Lu on 5/18/16.
 */
public class ActivityLogin extends AppCompatActivity {
    public static final String TAG = ActivityLogin.class.getSimpleName();
    private String mUsername;
    private String mPassword;
    private String mNasName;
    private InetAddress mNasIp;
    private String mAuthId;
    private Button mBtnLogin;
    private TextView tvLoginLocked;
    private TextView tvAttemptsLeft;
    private TextView tvAttemptsLeftNmbr;
    int attemptsLeftNmbr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "Creating ActivityLogin");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        TextView tvToolbarTitle = (TextView) findViewById(R.id.tv_toolbar_title);
        tvToolbarTitle.setText(getText(R.string.app_name));

        mNasName = (String) getIntent().getSerializableExtra("nasName");
        mNasIp = (InetAddress) getIntent().getSerializableExtra("nasIp");
        ImageView ivIconNas = (ImageView) findViewById(R.id.iv_icon_nas);
        ivIconNas.setImageResource(ActivityLogin.this.getResources().getIdentifier("icon_nas",
                "drawable", ActivityLogin.this.getPackageName()));
        TextView tvNasName = (TextView) findViewById(R.id.tv_nas_name);
        tvNasName.setText(mNasName);
        TextView tvNasIp = (TextView) findViewById(R.id.tv_nas_ip);
        tvNasIp.setText(mNasIp.getHostAddress());
        final EditText etUsername = (EditText) findViewById(R.id.et_username);
        final EditText etPassword = (EditText) findViewById(R.id.et_password);

        Log.d(TAG, "Chosen NAS Name: " + mNasName + " IP address: " + mNasIp.getHostAddress());
        mBtnLogin = (Button) findViewById(R.id.btn_login);
        mBtnLogin.setText(getApplicationContext().getResources().getString(R.string.btn_login));
        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClassLogin classLogin = new ClassLogin();
                mUsername = etUsername.getText().toString();
                mPassword = etPassword.getText().toString();
                Log.d(TAG, "Button clicked with: Username: " + mUsername + " Password: " + mPassword);
                mAuthId = classLogin.getAuthId(mNasIp, mUsername, mPassword);
                Log.d(TAG, "AuthId: " + mAuthId);
                if (mAuthId.length() == 0) {
                    loginIncorrect();
                } else {
                    //Take the user to ActivityPlanets
                    updateSharedPrefs();
                    Intent intentSystem = new Intent(ActivityLogin.this, ActivitySystem.class);
                    //intentSystem.putExtra("nasIp", mNasIp);
                    //intentSystem.putExtra("nasName", mNasName);
                    startActivity(intentSystem);
                }
            }
        });
        attemptsLeftNmbr = 3;
        tvAttemptsLeft = (TextView) findViewById(R.id.tv_attempts_left);
        tvAttemptsLeftNmbr = (TextView) findViewById(R.id.tv_attempts_left_nmbr);
        tvAttemptsLeftNmbr.setText(Integer.toString(attemptsLeftNmbr));
        tvLoginLocked = (TextView) findViewById(R.id.tv_login_locked);
    }

    public void updateSharedPrefs() {
        ClassSharedPrefMngr mSharedPrefsMngr = ClassSharedPrefMngr.getInstance();
        mSharedPrefsMngr.setmSharedPrefs(getApplicationContext());
        mSharedPrefsMngr.setNasName(mNasName);
        mSharedPrefsMngr.setNasIp(mNasIp.getHostAddress());
        mSharedPrefsMngr.setUsername(mUsername);
        mSharedPrefsMngr.setPassword(mPassword);
        mSharedPrefsMngr.setAuthId(mAuthId);
    }

    public void loginIncorrect() {
        attemptsLeftNmbr--;
        tvAttemptsLeft.setVisibility(View.VISIBLE);
        tvAttemptsLeftNmbr.setVisibility(View.VISIBLE);
        tvAttemptsLeftNmbr.setText(Integer.toString(attemptsLeftNmbr));
        if (attemptsLeftNmbr == 0) {
            mBtnLogin.setEnabled(false);
            tvLoginLocked.setVisibility(View.VISIBLE);
            tvLoginLocked.setBackgroundColor(Color.RED);
            tvLoginLocked.setText("LOGIN LOCKED!!!");
        }
    }
}
