package com.thecus.www.thecusconnect;

import android.os.StrictMode;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Roy Lu on 5/18/16.
 */
public class ClassLogin {
    public static final String TAG = ClassLogin.class.getSimpleName();

    public ClassLogin() {}

    public String getAuthId(InetAddress nasIp, String username, String password) {
        //Hack prevent crash (really, sending should be done using an async task)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String authId = "";
        try {
            String apiUri = "Login/?user=" + username + "&pwd=" + password;
            Log.d(TAG, "URI: " + apiUri);
            JSONObject apiJson = getJson(nasIp, apiUri);
            authId = apiJson.getString("authid");
            Log.d(TAG, "AuthId: " + authId);
        } catch (JSONException e) {
            Log.e(TAG, "JSON exception", e);
        }
            return authId;
    }

    public JSONObject getJson(InetAddress nasIp, String apiUri) {
        JSONObject inboundJson = new JSONObject();
        try {
            String portHttp = "8080";
            String portHttps = "433";
            String apiUrl = "http:/" + nasIp + ":" + portHttp + "/" + apiUri;
            String apiUrlHttps = "https:/" + nasIp + ":" + portHttps + "/" + apiUri;
            Log.d(TAG, "URL: " + apiUrl);
            //Call urlOpen to get URL and receive JSON message in string
            String inboundStr = urlOpen(apiUrl);
            inboundJson = new JSONObject(inboundStr);
            Log.d(TAG, "JSON object: " + inboundJson);
        } catch (IOException e) {
            Log.e(TAG, "IOException", e);
        } catch (JSONException e) {
            Log.e(TAG, "JSON exception", e);
        }
        return inboundJson;
    }

    public String urlOpen(String apiUrl) throws IOException {
        String inboundMessage = "";
        try {
            Log.d(TAG, "Initiating UrlOpen");
            URL url = new URL(apiUrl);
            //InputStreamReader records the inbound message from sending the URL
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
            inboundMessage = bufferedReader.readLine();
            Log.d(TAG, "Inbound message: " + inboundMessage);
            StringBuilder stringBuilder = new StringBuilder();
            try {
                /*
                String string;
                while ((string = bufferedReader.readLine()) != null) {
                    stringBuilder.append(string).append("\n");
                }
                Log.d(TAG, "Inbound stringBuilder.toString: " + stringBuilder.toString());
                */
            } finally {
                bufferedReader.close();
            }
        } catch (MalformedURLException e) {
            Log.e(TAG, "URLException", e);
        } catch (IOException e) {
            Log.e(TAG, "IOException", e);
        }
        Log.d(TAG, "Inbound content: " + inboundMessage);
        return inboundMessage;
    }
}
