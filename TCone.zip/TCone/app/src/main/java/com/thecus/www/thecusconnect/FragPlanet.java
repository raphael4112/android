package com.thecus.www.thecusconnect;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Locale;

/**
 * Created by Roy Lu on 5/16/16.
 * Fragment that appears in the "content_frame", shows a planet
 */
public class FragPlanet extends Fragment {
    public static final String ARG_PLANET_NUMBER = "planet_number";

    public FragPlanet() {
        // Empty constructor required for fragment subclasses
    }

    public static Fragment newInstance(int planetNum) {
        Fragment fragPlanet = new FragPlanet();
        Bundle args = new Bundle();
        args.putInt(FragPlanet.ARG_PLANET_NUMBER, planetNum);
        fragPlanet.setArguments(args);
        return fragPlanet;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View fragView = inflater.inflate(R.layout.frag_planet, container, false); //Instantiate view.
        int planetNum = getArguments().getInt(ARG_PLANET_NUMBER); //Get the planet called.
        String planetName = getResources().getStringArray(R.array.planets_array)[planetNum];//Get the planet name called stored in planetName.

        int imageId = getResources().getIdentifier(planetName.toLowerCase(Locale.getDefault()), //Get image by calling planet name in lower case.
                "drawable", getActivity().getPackageName());
        ImageView mImageView = ((ImageView) fragView.findViewById(R.id.imageview_frag_planet));
        mImageView.setImageResource(imageId);

        getActivity().setTitle(planetName);
        return fragView;
    }
}