package com.thecus.www.thecusconnect;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ActivityDiscover extends AppCompatActivity {

    public static final String TAG = ActivityDiscover.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) { //Method run when the activity is created
        super.onCreate(savedInstanceState); //Background code in Android Activity is run here
        setContentView(R.layout.activity_discover);  //Set the layout

        //Override default toolbar layout
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layout_discover);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        TextView tvToolbarTitle = (TextView) findViewById(R.id.tv_toolbar_title);
        tvToolbarTitle.setText(getText(R.string.app_name));

        TextView tvNasName = (TextView) findViewById(R.id.tv_nas_name);
        String nasName = "Office NAS N5200";
        tvNasName.setText(nasName);

        Fragment fragNasList = FragNasList.newInstance();
        FragmentManager fragMngr = getFragmentManager();
        FragmentTransaction fragTrans = fragMngr.beginTransaction();
        fragTrans.add(R.id.framelayout_frag_nas_list, fragNasList);
        fragTrans.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tool_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle tool bar item clicks here. The action bar will automatically handle clicks
        // on the Home/Up button, so long as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_refresh) {
            Fragment mFragNasList = FragNasList.newInstance();
            FragmentManager mFragMngr = getFragmentManager();
            FragmentTransaction mFragTrans = mFragMngr.beginTransaction();
            mFragTrans.replace(R.id.framelayout_frag_nas_list, mFragNasList);
            mFragTrans.commit();
            return true;
        }
        if (id == R.id.action_nav_drawer) {

            Intent navDrawer = new Intent(this, ActivityPlanets.class);
            startActivity(navDrawer);
            return true;
        }
        if (id == R.id.action_system) {

            Intent storage = new Intent(this, ActivitySystem.class);
            startActivity(storage);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
