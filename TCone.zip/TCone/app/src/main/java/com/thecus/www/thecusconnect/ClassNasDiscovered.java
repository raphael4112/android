package com.thecus.www.thecusconnect;

import android.util.Log;

import java.net.InetAddress;
import java.util.List;

/**
 * Created by Roy Lu on 5/5/16.
 */
public class ClassNasDiscovered {

    public static final String TAG = ClassNasDiscovered.class.getSimpleName();
    public String mName;
    public InetAddress mIpInet;
    public String mIpStr;
    public int mPort;
    public String mUser;
    public String mType;
    public String mVersion;

    public ClassNasDiscovered() {}

    public void setAttr(int attrType0, int attrType1, byte[] attrContentByte, List<Integer> attrContentInt, String attrContentStr, InetAddress hostIpInet) {
        switch (attrType0) {
            case 1: {
                switch (attrType1) {
                    case 0: {
                        break;
                    }
                    case 1: {
                        break;
                    }
                    case 2: {
                        setIpInet(hostIpInet);
                        setIpStr(hostIpInet.getHostAddress());
                        Log.d(TAG, "NAS IP saved: " + hostIpInet);
                        break;
                    }
                }
                break;
            }
            case 2: {
                switch (attrType1) {
                    case 0: { //[20] NAS Type
                        setType(attrContentStr);
                        Log.d(TAG, "NAS Type saved: " + attrContentStr);
                        break;
                    }
                    case 1: { //[21] NAS Name
                        setName(attrContentStr);
                        Log.d(TAG, "NAS Name saved: " + attrContentStr);
                        break;
                    }
                    case 2: { //[22] version
                        setVersion(attrContentStr);
                        Log.d(TAG, "NAS firmware version saved: " + attrContentStr);
                        break;
                    }
                }
                break;
            }
        }
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getName() {
        return this.mName;
    }

    public void setIpInet(InetAddress ip) {
        this.mIpInet = ip;
    }

    public InetAddress getIpInet() {
        return this.mIpInet;
    }

    public void setIpStr(String ip) {
        this.mIpStr = ip;
    }

    public String getIpStr() {
        return this.mIpStr;
    }

    public void setPort(int mPort) {
        this.mPort = mPort;
    }

    public int getPort() {
        return this.mPort;
    }

    public void setUser(String mPort) {
        this.mUser = mPort;
    }

    public String getUser() {
        return this.mUser;
    }

    public void setType(String mPort) {
        this.mType = mPort;
    }

    public String getType() {
        return this.mType;
    }

    public void setVersion(String mPort) {
        this.mVersion = mPort;
    }

    public String getVersion() {
        return this.mVersion;
    }
}
