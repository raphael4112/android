package com.thecus.www.thecusconnect;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class AdapterNasList extends ArrayAdapter {
    public static final String TAG = AdapterNasList.class.getSimpleName();
    private Context mContext;
    private int mLayout;
    private List<ClassNasDiscovered> mNasList;

    public AdapterNasList(Context context, int layout, List<ClassNasDiscovered> nasList) {
        super(context , layout, nasList);
        mContext = context;
        mLayout = layout;
        mNasList = nasList;
    }

    private static class ViewHolder {
        public ImageView iconNasView;
        public TextView nasNameView;
        public TextView nasIpView;
        public TextView nasUserView;
    }

    //Interface for receiving click events from cells.
    public interface OnItemClickListener {
        public void onClick(View view, int position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        ViewHolder viewHolder = new ViewHolder();

        if (convertView == null) { //First verify that convertView is not null
            //This is a new view we inflate the new layout
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.item_nas, null);
            //Now we can fill the layout with the right values.
            ImageView ivIconNas = (ImageView) view.findViewById(R.id.imageview_nas_icon);
            TextView tvNasName = (TextView) view.findViewById(R.id.textview_nas_name);
            TextView tvNasIp = (TextView) view.findViewById(R.id.textview_nas_ip);
            TextView tvNasUser = (TextView) view.findViewById(R.id.textview_nas_user);
            viewHolder.iconNasView = ivIconNas;
            viewHolder.nasNameView = tvNasName;
            viewHolder.nasIpView = tvNasIp;
            viewHolder.nasUserView = tvNasUser;
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }

        ClassNasDiscovered nas = mNasList.get(position);
        viewHolder.nasNameView.setText(nas.getName());
        viewHolder.nasIpView.setText(nas.getIpStr());
        viewHolder.nasUserView.setText(nas.getUser());
        viewHolder.iconNasView.setImageResource(mContext.getResources().getIdentifier("icon_nas",
                "drawable", mContext.getPackageName()));
        return view;
    }

    public int getItemCount() {
        return mNasList.size();
    }

}


