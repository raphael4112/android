package com.thecus.www.thecusconnect;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.StrictMode;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Roy Lu on 5/6/16.
 */
public class ClassUdpTools {

    public static final String TAG = ClassUdpTools.class.getSimpleName();
    private static Context mContext;

    public static List<String> mNasIpList;
    public static List<ClassNasDiscovered> mNasList;
    private static DatagramSocket mSendSocket;
    private static DatagramSocket mReceiveSocket;
    private static final int SEND_PORT = 11000;
    private static final int RECEIVE_PORT = 11001;
    private static final int TIMEOUT_MS = 2000;
    private static final int BUFFER_SIZE = 1024;
    private static WifiManager mWifiManager;
    private static DhcpInfo mDhcpInfo;

    public ClassUdpTools(Context context) {
        mContext = context;
    } //Constructor

    /*
     * This function finds NAS machines using UDP broadcast and puts found NAS machines
     * into an ArrayList.
     */
    public void run() {
        Log.d(TAG, "Initializing UDP broadcast");
        long startRun = System.currentTimeMillis();
        //Hack prevent crash (really, sending should be done using an async task)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            mWifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
            int mLocalIpInt = mWifiManager.getConnectionInfo().getIpAddress();
            String mLocalIp = String.format("%d.%d.%d.%d", (mLocalIpInt & 0xff),(mLocalIpInt >> 8 & 0xff),(mLocalIpInt >> 16 & 0xff),(mLocalIpInt >> 24 & 0xff));
            Log.d(TAG, "Initializing socket at " + mLocalIp + ":" + SEND_PORT);

            mSendSocket = new DatagramSocket(SEND_PORT);
            mSendSocket.setBroadcast(true);
            mSendSocket.setSoTimeout(TIMEOUT_MS); //Set timeout so our application doesn't run unstopped.
            mReceiveSocket = new DatagramSocket(RECEIVE_PORT);
            mReceiveSocket.setSoTimeout(TIMEOUT_MS); //Set timeout so our application doesn't run unstopped.

            ClassUdpTools.this.sendUDPMsg(); //Call broadcast function.
            mSendSocket.close();
            ClassUdpTools.this.listenForResponses(); //Call listen for response function.
            mReceiveSocket.close();
            Log.d(TAG, "Socket closes at " + (System.currentTimeMillis() - startRun) + " ms");
        } catch (IOException e) {
            Log.e(TAG,"Could not send discovery request", e);
        }
    }

    public void sendUDPMsg() throws IOException {
        /*
         * Discovery message is 22 byte long. First two must be 1 to get a response. The sequence
         * goes 2B + 6B + 8B + I + 2B, where I has a size of four bytes.
         */
        ByteArrayOutputStream mStream = new ByteArrayOutputStream(); //Set up our byte stream.
        mStream.write(1);
        mStream.write(1);
        for (int i=0; i<20; i++) {
            mStream.write(0);
        }
        byte[] sendDataByte = mStream.toByteArray(); //Turn the byte stream into an array.
        String sendDataStr = mStream.toString();
        InetAddress mBroadcastAddress = getBroadcastAddress(); // Call method to get broadcast address. See below for detail.
        DatagramPacket broadcastPacket = new DatagramPacket(sendDataByte, sendDataByte.length,
              mBroadcastAddress, SEND_PORT);
        mSendSocket.send(broadcastPacket);
        Log.d(TAG, "Broadcast packet data: " + sendDataStr +"; length: " + sendDataByte.length);
        Log.d(TAG, "Broadcast packet send to " + mBroadcastAddress + ":" + SEND_PORT);
    }

    /*
     * This method returns the IP address for broadcasting.
     * Broadcast address can be different depending on the network. So the default 255.255.255.255
     * may not always work. Run this function to get the network's broadcast address.
     */
    private InetAddress getBroadcastAddress() throws IOException {
        mDhcpInfo = mWifiManager.getDhcpInfo();
        if (mDhcpInfo == null) {
            Log.d(TAG, "Could not get DHCP info");
            return null;
        } else {
            Log.v(TAG, "Get DHCP information: " + mDhcpInfo);
        }
        int broadcast = (mDhcpInfo.ipAddress & mDhcpInfo.netmask) | ~mDhcpInfo.netmask;
        byte[] quads = new byte[4];
        for (int k = 0; k < 4; k++) {
            quads[k] = (byte) ((broadcast >> k * 8) & 0xFF);
        }
        Log.d(TAG, "Found broadcast address at " + InetAddress.getByAddress(quads));
        return InetAddress.getByAddress(quads);
    }

    private void listenForResponses() throws IOException {
        long start = System.currentTimeMillis();
        mNasIpList = new ArrayList<>(); //An arraylist of discovered NAS IP addresses
        mNasList = new ArrayList<ClassNasDiscovered>(); //An arraylist of discovered NAS in custom object NasNodes
        //Give a proper buffer size for the incoming packets
        byte[] receiveData = new byte[BUFFER_SIZE];
        //Loop and try to receive responses until the timeout elapses.
        int nasOrder = 1;
        try {
            while (true) {
                DatagramPacket inboundPacket = new DatagramPacket(receiveData, receiveData.length);
                //Use socket to receive packet, then get the packet's length and IP address.
                mReceiveSocket.receive(inboundPacket);
                int packetLength = inboundPacket.getLength();
                InetAddress hostIpInet= inboundPacket.getAddress();
                String hostIpStr = inboundPacket.getAddress().getHostAddress();

                //Store segments of the incoming packet into appropriate variables
                byte inboundBytes[] = inboundPacket.getData();
                byte packageType0[] = Arrays.copyOfRange(inboundBytes,0,1);
                byte packageType1[] = Arrays.copyOfRange(inboundBytes,1,2);
                byte ipAddress[] = Arrays.copyOfRange(inboundBytes,2,8);
                byte key[] = Arrays.copyOfRange(inboundBytes,8,16);
                byte pkLength[] = Arrays.copyOfRange(inboundBytes,16,20);
                byte allAttrByte[] = Arrays.copyOfRange(inboundBytes,20, packetLength);

                Log.d(TAG, "[Server" + nasOrder + "] Packet received after " + (System.currentTimeMillis() - start) + " ms");
                Log.d(TAG, "[Server" + nasOrder + "] Host IP: " + hostIpInet);
                Log.d(TAG, "[Server" + nasOrder + "] Packet length: " + packetLength + " bytes");
                if (hostIpStr != null) {
                    mNasIpList.add(hostIpStr);
                    //ByteArrayInputStream can store byte array
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(allAttrByte);
                    //Store attribute information in an ArrayList of integers
                    ArrayList<Integer> allAttrInt = new ArrayList<Integer>(); //An arraylist of incoming packet message converted to integers
                    for (int i=0; i < packetLength; i++) {
                        allAttrInt.add(byteArrayInputStream.read()); //.read() returns one integer at a time of the input byte stream.
                    }
                    //Store attribute information in a string
                    String allAttrStr = new String(allAttrByte);
                    //Calling method to parse attribute information
                    parseAttributes(byteArrayInputStream, allAttrByte, allAttrInt, allAttrStr, packetLength, hostIpInet, nasOrder);
                }
                nasOrder = nasOrder + 1; //Increment to the next incoming packet
            }
        } catch (SocketTimeoutException e) {
            Log.d(TAG, "Socket timed out at " + (System.currentTimeMillis() - start) + " ms");
        }
    }

    private void parseAttributes (ByteArrayInputStream byteArrayInputStream, byte[] allAttrByte,
                                  ArrayList<Integer> allAttrInt, String allAttrStr, int packetLength,
                                  InetAddress hostIpInet, int nasOrder) {
        ClassNasDiscovered nas = new ClassNasDiscovered();
        Log.v(TAG, "Attributes received");
        Log.v(TAG, "All attributes in integer: " + allAttrInt);
        Log.v(TAG, "All attributes in string: " + allAttrStr);
        //Define starting position of attribute and position of attribute content
        int attrPos = 0;
        int attrContentPos = attrPos + 6;
        List<Integer> attrContentInt = new ArrayList<>(); //Initialize a list to store attribute content in integer form
        try {
            while (attrPos < packetLength) {
                attrContentInt.clear();
                int attrType0 = allAttrInt.get(attrPos);
                if (attrType0 != 1 && attrType0 != 2) {
                    break;
                }
                int attrType1 = allAttrInt.get(attrPos + 1);
                int attrLength = allAttrInt.get(attrPos + 2);
                for (int i = 0; i < attrLength; i++) {
                    attrContentInt.add(i, allAttrInt.get(attrContentPos + i));
                }
                byte attrContentByte[] = Arrays.copyOfRange(allAttrByte, attrContentPos, attrContentPos + attrLength);
                String attrContentStr = new String(attrContentByte);

                Log.v(TAG, "Attr type: [" + attrType0 + attrType1 + "] Attr in int: " + attrContentInt);
                Log.v(TAG, "Attr type: [" + attrType0 + attrType1 + "] Attr in str: " + attrContentStr);
                Log.v(TAG, "attrPos: " + attrPos + " attrContentPos: " + attrContentPos + " attrType0: " + attrType0 + " attrType1: " + attrType1 + " attrLength: " + attrLength);
                Log.v(TAG, "Attribute saved");
                attrPos = attrContentPos + attrLength;
                attrContentPos = attrPos + 6;
                nas.setAttr(attrType0, attrType1, attrContentByte, attrContentInt, attrContentStr, hostIpInet);
            }
        } catch (Exception e) {
            Log.e(TAG, "Attribute Save Error");
        }
        mNasList.add(nas);
    }

    public List returnNasIpList() {
        return mNasIpList;
    }

    public List returnNasList() {
        return mNasList;
    }
}