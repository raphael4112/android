package com.example.raphael.network;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.*;

public class NetworkActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network);
    }

    public static class Ex_ArrayList{
        public static void main(String[] args){
            ArrayList al = new ArrayList();
            al.add("File Services");
            al.add("AFP");
            al.add("FTP");
            al.add("NFS");
            al.add("Samba");
            al.add("TFTP");
            al.add("WebDAV");
            al.add("Connect Service");
            al.add("HTTP");
            al.add("iTunes");
            al.add("SMB/CIFS");
            al.add("SNMP");
            al.add("SSH");
            al.add("UPnP");
            al.add("VPN");
            ListIterator it = al.listIterator();
            while(it.hasNext()){
                int index = it.nextIndex();
                String data = (String)it.next();
                System.out.println(index + "=" + data +",");
            }
            System.out.println();
        }
    }


}
